﻿using SharpDX.DirectWrite;

namespace AfterBurner
{
    internal class lBuffer
    {
        public string Text;
        public TextLayout TextLayout;
    }
}
