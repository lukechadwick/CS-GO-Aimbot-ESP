﻿using System.Windows.Shapes;
using System.Windows.Media;
using System.Collections.Generic;
using System.Windows;


namespace Notepad__
{
    public class Drawings
    {
    }
}
