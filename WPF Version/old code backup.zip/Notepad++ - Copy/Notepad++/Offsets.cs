﻿namespace Notepad__
{
    public class Offsets
    {
        public static int LocalPlayer = 0xAADFFC; //LocalPlayer
        public static int EntityList = 0x4A8A684;  //Entity List
        public static int ViewMatrix = 0x04A7C0E4; //ViewMatrix

        public static int CrossID = 0xB2B4;
        public static int Position = 0x134;
        public static int AimPunch = 0x301C;

        public static int Dist = 0x10; //Entitiy distaance
        public static int Dorm = 0xE9; //m_bdormant
        public static int Team = 0xF0;  //Team Number
        public static int Health = 0xFC; //Health
        public static int bone = 0x2698; //BoneMatrix
        public static int spots = 0x97C;  //Team Number
        public static int flags = 0x100; //Health
        public static int m_observerT = 0x3380; //BoneMatrix
    }
}